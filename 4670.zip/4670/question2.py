import numpy as np

#D = dict(np.load('data.npz'))
#Print(D)
#from print statement above
input_dict = {"A": np.array([1837.16233766, 1784.4025974 ]), "B": np.array([1816.87012987, 1443.49350649]), "C": np.array([1143.16883117, 1743.81818182]), "D": np.array([ 757.61688312, 1642.35714286]), "E": np.array([ 822.55194805, 1995.44155844]), "F": np.array([1179.69480519, 2169.95454545]), "l": np.array(4.875), "w": np.array(2.875), "h": np.array(2.25), "G": np.array([2470.27922078, 1516.54545455]), "H": np.array([2531.15584416,  652.0974026 ]), }

#length = FA (x-axis), width = FE(y-axis), height = FC (z-axis)
#World coordinates:
l = input_dict["l"]
w = input_dict["w"]
h = input_dict["h"]
A = [l, 0, 0]
B = [l, 0, h]
C = [0, 0, h]
D = [0, w, h]
E = [0, w, 0]
F = [0, 0, 0]
#image coordinates
a = input_dict["A"]
b = input_dict["B"]
c = input_dict["C"]
d = input_dict["D"]
e = input_dict["E"]
f = input_dict["F"]

coordinate_image = np.array([a, b, c, d, e, f])
coordinate_world = np.array([A, B, C, D, E, F])
#Find A
A = []
for i in range(6):
    X = coordinate_world[i][0]
    Y = coordinate_world[i][1]
    Z = coordinate_world[i][2]
    U = coordinate_image[i][0]
    V = coordinate_image[i][1]
    #Append each row
    A.append([-X, -Y, -Z, -1, 0, 0, 0, 0, U*X, U*Y, U*Z, U])
    A.append([0, 0, 0, 0, -X, -Y, -Z, -1, V*X, V*Y, V*Z, V])

A = np.asarray(A)
#find eigenvector of (A_transpose)(A) with smallest eigenval
eigenvalues, eigenvectors = np.linalg.eig((A.T)@A)
p = eigenvectors[:, np.argmin(eigenvalues)]
p_reshaped = np.reshape(p, (3, 4))
print(p_reshaped)
np.save("camera.npy", p_reshaped)
homography = np.delete(p_reshaped, 2, 1)
print(homography)
np.save("homography.npy", homography)
#For every single 
G = input_dict["G"]
G_homog = np.append(G, 1)
world_G = np.linalg.inv(homography) @ G_homog
world_G = world_G / world_G[-1]
world_G[-1] = 0.0
print(world_G)
np.save("foot.npy", world_G)