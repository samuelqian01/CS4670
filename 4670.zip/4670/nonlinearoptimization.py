import numpy as np
from scipy.optimize import minimize

D = dict(np.load('data.npz'))

print(D)

class QuadraticRational:
    def __init__(self,a,b,c,d,p,q):
        self.a = a
        self.b = b
        self.c = c
        self.d = d
        self.p = p
        self.q = q

    def func(self, x):
        return ((self.a*x + self.b)**2 + (self.c*x + self.d)**2)/((self.p*x + self.q)**2)

    def jac(self,x):
        term1 = (2*(self.a**2 + self.c**2)*x + 2*(self.a*self.b + self.c*self.d))/((self.p*x + self.q)**2)
        term2 = ((self.a*x + self.b)**2 + (self.c*x + self.d)**2)*2*(self.p*x + self.q)*self.p
        term2 = term2 / (self.p*x + self.q)**3
        return term1 - term2
    def initialization(self):
        return 0.5*(-self.b/self.a - self.d/self.c)




def solve_rational(a,b,c,d,p,q):
    function = QuadraticRational(a,b,c,d,p,q) 
    x0 = function.initialization()
    return minimize(lambda x:function.func(x),x0, jac=lambda x: function.jac(x)).x[0] 


